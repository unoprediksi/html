# frozen_string_literal: true

module HTML
  class Pipeline
    VERSION = '2.14.2'
  end
end
